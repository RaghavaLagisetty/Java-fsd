import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SelAuto {
    public static void main(String[] args) throws InterruptedException {
        // Register the Chrome driver
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\ragha\\Downloads\\chromedriver.exe");

        // Create an object to the driver - object to the browser
        WebDriver wd = new ChromeDriver(); // wd is the controller object to web browser

        // Maximize the screen
        wd.manage().window().maximize();

        // Open the web URL
        wd.get("https://www.amazon.in/");

        // Wait for the "Start here." link to be clickable and then click it
        WebDriverWait wait = new WebDriverWait(wd, 10);
        WebElement startHereLink = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Start here.")));
        startHereLink.click();

        // Fill in the form fields with explicit waits
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ap_customer_name"))).sendKeys("Raghava");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ap_phone_number"))).sendKeys("7995887499");
        //wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ap_email"))).sendKeys("ka@gmail.com");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ap_password"))).sendKeys("123456789");

        // Click the continue button
        wait.until(ExpectedConditions.elementToBeClickable(By.id("continue"))).click();

        // Close the browser after a delay
        Thread.sleep(20000);
        wd.close();
    }
}
