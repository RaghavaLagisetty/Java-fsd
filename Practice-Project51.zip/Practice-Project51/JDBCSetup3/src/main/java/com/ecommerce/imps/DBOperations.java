package com.ecommerce.imps;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecommerce.dbcon.DbConnection;

@WebServlet("/DBOperations")
public class DBOperations extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public DBOperations() {
        super();
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            PrintWriter out = response.getWriter();
            out.println("<html><body>");

            // Establish database connection using DriverManager
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "root");

            if (conn != null) {
                out.println("Database connection established successfully.<br>");

                Statement stmt = conn.createStatement();

                // Create database
                int createDbResult = stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS mydatabase");
                out.println("Create database result: " + createDbResult + "<br>");

                // Use database
                int useDbResult = stmt.executeUpdate("USE mydatabase");
                out.println("Use database result: " + useDbResult + "<br>");

                // Drop database
                int dropDbResult = stmt.executeUpdate("DROP DATABASE IF EXISTS mydatabase");
                out.println("Drop database result: " + dropDbResult + "<br>");

                stmt.close();
                conn.close();
            } else {
                out.println("Failed to establish database connection.<br>");
            }

            out.println("</body></html>");

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
