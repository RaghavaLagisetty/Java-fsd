package practice_project1;

class defAccessSpecifiers{
	void display() {
		System.out.println("You are using default access specifier");
	}
}
public class accessSpecifiers1 {
	public static void main(String[] args) {
		System.out.println("Default Access Specifier");
		defAccessSpecifiers obj=new defAccessSpecifiers();
		obj.display();
	}

}
