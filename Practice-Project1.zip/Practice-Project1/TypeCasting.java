package practice_project1;

public class TypeCasting {
	public static void main(String[] args) {
		
		System.out.println("Implicit Type Casting");
		char a='A';
		System.out.println("Character Value : "+a);
		
		int b=a;
		System.out.println("Integer Value : "+b);
		
		float c=a;
		System.out.println("Float Value: "+c);
		
		long d=a;
		System.out.println("Long Value: "+d);
		
		double e=a;
		System.out.println("Double Value: "+e);
		
				
		System.out.println("\n");
		
		System.out.println("Explicit Type Casting");
		
		double x=45.5;
		int y=(int)x;
		System.out.println("Double Value: "+x);
		System.out.println("Integer Value: "+y);
		
    }

}
