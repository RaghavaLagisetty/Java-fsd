package pack16;


class MyException extends Exception{
	String str1;
	 MyException(String str2) {
		 str1=str2;
	}
	 public String toString() {
		 return ("My Exception Occured: "+str1);
	 }
}
public class Example1 {
	public static void main(String[] args) {
		try {
			System.out.println("Starting of try block");
			throw new MyException("This is my error message");
		}
		catch(MyException ex) {
			System.out.println("Catch Block");
			System.out.println(ex);
		}
	}

}
