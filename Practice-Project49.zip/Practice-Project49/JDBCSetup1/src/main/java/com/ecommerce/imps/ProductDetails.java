package com.ecommerce.imps;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecommerce.dbcon.DbConnection;
//import com.mysql.cj.xdevapi.Statement;

/**
 * Servlet implementation class ProductDetails
 */
@WebServlet("/ProductDetails")
public class ProductDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        
        try {
            // JDBC code to connect to database using DriverManager
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conObj = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce","root", "root");
            
            // Set auto-commit to false
            conObj.setAutoCommit(false);
            
            Statement stmt = conObj.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            
            // Execute SQL INSERT statement
            int rowsAffected = stmt.executeUpdate("INSERT INTO eproduct (name, price, date_added) VALUES ('New Product', 17800.00, NOW())");
            
            if (rowsAffected > 0) {
                out.println("Product inserted successfully.<br>");
            } else {
                out.println("Failed to insert product.<br>");
            }
            
            ResultSet rst = stmt.executeQuery("SELECT * FROM eproduct");
            
            while (rst.next()) {
                out.println(rst.getInt("ID") + ", " + rst.getString("name") + "<br>");
            }
            
            stmt.close();
            
            // Commit the transaction
            conObj.commit();
            
            // Close the connection
            conObj.close();
            
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage() + "<br>");
        }
        
        out.println("</body></html>");
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
