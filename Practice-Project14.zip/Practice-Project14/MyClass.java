package pack14;

public class MyClass {
	public static void main(String[] args) {
		int[] arr=new int[3];
		try {
			arr[7]=3;
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("The array index is out of bounds");
		}
		finally {
			System.out.println("The array size is:"+arr.length);
		}
	}

}
