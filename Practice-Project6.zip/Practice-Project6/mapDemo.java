package practice_project1;
import java.util.*;

public class mapDemo {
	public static void main(String[] args) {
		
		HashMap<Integer,String> hm=new HashMap<Integer,String>();      
	      hm.put(1,"Simplilearn");    
	      hm.put(2,"Training");    
	      hm.put(3,"Program");   
	       
	      System.out.println("\nThe elements of Hashmap: ");  
	      for(Map.Entry m:hm.entrySet()){    
	       System.out.println(m.getKey()+" "+m.getValue());    
	      }
	       
	      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
	      ht.put(4,"Java");  
	      ht.put(5,"Programming");  
	      ht.put(6,"Language");    

	      System.out.println("\nThe elements of HashTable: ");  
	      for(Map.Entry n:ht.entrySet()){    
	       System.out.println(n.getKey()+" "+n.getValue());    
	      }
	      
	      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
	      map.put(7,"Arrays");    
	      map.put(8,"Stacks");    
	      map.put(9,"Queue");
	      map.put(10, "Trees");
	      
	      System.out.println("\nThe elements of TreeMap: ");  
	      for(Map.Entry l:map.entrySet()){    
	       System.out.println(l.getKey()+" "+l.getValue());    
	      }    
	      
	   }  


}
