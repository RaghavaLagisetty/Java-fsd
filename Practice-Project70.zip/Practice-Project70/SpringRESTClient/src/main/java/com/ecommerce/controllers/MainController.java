package com.ecommerce.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.ecommerce.beans.Quote;

import java.util.Arrays;
import java.util.List;

@Controller
public class MainController {

    @RequestMapping("/")
    @ResponseBody
    public String index() {
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Quote[]> responseEntity = restTemplate.getForEntity("https://type.fit/api/quotes", Quote[].class);
        Quote[] quotes = responseEntity.getBody();
        List<Quote> quoteList = Arrays.asList(quotes);
        return quoteList.toString();
    }
}